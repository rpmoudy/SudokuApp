package com.example.slick.sudokuapp;

import android.util.AttributeSet;
import android.support.v7.widget.GridLayout;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.reflect.Array;

public class SudokuField {

    GridLayout sudokuGrid;
    SudokuCell[] sudokuCellArray = new SudokuCell[81];

    public SudokuField(GridLayout sGrid) {

        sudokuGrid = sGrid;

        int rowCount = -1;
        //int colCount = 1;
        int value = 0;
        int count = 0;

        for (int i = 1; i <= 9; i++) { //Row position

            rowCount = rowCount + 1; //Need to shift values over by 1 each row

            for (int j = 1; j <= 9; j++) { //Column position

                //Every other row shift values
                if (i <= 1) { //First Row don't shift values
                    value = j;
                } else value = j + rowCount;

                if (value >= 9) { //If value is 9 or more, cycle back 8 and keep adding
                    value = value - 8;
                }

                SudokuCell mySudokuCell = new SudokuCell(i, j, value); //Setup new SudokuCell
                this.sudokuCellArray[count] = mySudokuCell; //Add SudokuCell to list

                //Setup grid parameter
                GridLayout.Spec row = GridLayout.spec(i-1, 1); //Grid row starts at 0
                GridLayout.Spec colspan = GridLayout.spec(j-1, 1); //Grid col starts at 0
                GridLayout.LayoutParams gridLayoutParam = new GridLayout.LayoutParams(row, colspan);

                sudokuGrid.addView(mySudokuCell.returnView(),gridLayoutParam); //Add TextView to Grid Layout
                count++;
            }
        }



    }

    public GridLayout getSudokuGrid() {
        return sudokuGrid;
    }



}
