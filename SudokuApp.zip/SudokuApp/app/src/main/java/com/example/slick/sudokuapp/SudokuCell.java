package com.example.slick.sudokuapp;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import org.w3c.dom.Text;

public class SudokuCell {

    TextView sTextView;

    int row;
    int column;
    int grid;
    int value;
    boolean selected = false;
    boolean similarNum = false;

    public SudokuCell(int sRow, int sColumn, int sValue){

        row = sRow;
        column = sColumn;
        value = sValue;

        //sTextView = sView;

        //Assign grid location based on cell position
        int gridRow,gridCol;

        gridRow = (int) Math.ceil(row/3);
        gridCol = (int) Math.ceil(column/3);

        //First row of grids
        if (gridRow == 1){
            if (gridCol == 1){
                grid = 1;
            }
            else if (gridCol == 2){
                grid = 2;
            }
            else if (gridCol == 3) {
                grid = 3;
            }
        }
        //Second row of grids
        else if (gridRow == 2){
            if (gridCol == 1){
                grid = 4;
            }
            else if (gridCol == 2){
                grid = 5;
            }
            else if (gridCol == 3) {
                grid = 6;
            }
        }
        //Third row of grids
        else if (gridRow == 3){
            if (gridCol == 1){
                grid = 7;
            }
            else if (gridCol == 2){
                grid = 8;
            }
            else if (gridCol == 3) {
                grid = 9;
            }
        }

       //this.setView();

    }

    //Set TextView Attributes
    public void setView(){

        //sTextView.setBackgroundResource(R.drawable.border);
        //sTextView.setPadding(5,5,5,5);
        //sTextView.setTextSize(18);
        //sTextView.setGravity(Gravity.CENTER);
        //sTextView.setTextColor(Color.BLACK);

        if (this.value == 0){
            this.sTextView.setText("");
        }
        else {
            this.sTextView.setText(String.valueOf(this.value));
        }

    }

    //Set "Text Hint" View Value - For User Selection
    public void setViewValue(){

        if (this.value == 0){
            this.sTextView.setText("");
        }
        else {
            this.sTextView.setText(String.valueOf(this.value));
        }

    }


    //Return internal values of SudokuCell
    public TextView returnView(){
        return this.sTextView;
    }

    public int getRow(){
        return this.row;
    }

    public int getColumn(){
        return this.column;
    }

    public int getGrid(){
        return this.grid;
    }

    public int returnValue(){
        return this.value;
    }

}
