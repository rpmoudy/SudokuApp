package com.example.slick.sudokuapp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.Stack;
import java.util.TreeSet;

public class SudokuGenerator {

   public int[][] sudokuArray = new int[9][9]; //values

    public SudokuGenerator() {

        boolean oneRowBack = false;
        Stack<Integer> sudokuValues = new Stack<>();

        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++){

                if(sudokuValues.empty()){
                    sudokuValues = returnValues(i,j);
                }

                if(sudokuValues.empty()){ //Not able to solve, restart puzzle.
                    sudokuArray = new int[9][9];
                    i = -1;
                    break;
                }

                //Randomly generate num from valid sudoku nums
                int num = generateNum(sudokuValues);

                //Sometimes for some reason returns 0 above...
                num = (num == 0 ? sudokuValues.pop() : num);

                if(num != this.sudokuArray[i][j]){
                    this.sudokuArray[i][j] = num;
                    while(!sudokuValues.empty()){
                        sudokuValues.pop();
                    }
                }

            }

        }

    }

    public int generateNum(Stack<Integer> sNum){

        Random rand = new Random();
        int num = 0;
        int randomNum = rand.nextInt(sNum.size()+1);

        for(int i = 0; i < randomNum; i++){
            num = sNum.pop();
        }

        return num;

    }

    public int getGrid(int row, int col) {

        int gridRow, gridCol;
        int grid = 0;

        gridRow = (int) Math.ceil((double)row / 3.0);
        gridCol = (int) Math.ceil((double)col / 3.0);

        //First row of grids
        if (gridRow == 1) {
            if (gridCol == 1) {
                grid = 1;
            } else if (gridCol == 2) {
                grid = 2;
            } else if (gridCol == 3) {
                grid = 3;
            }
        }
        //Second row of grids
        else if (gridRow == 2) {
            if (gridCol == 1) {
                grid = 4;
            } else if (gridCol == 2) {
                grid = 5;
            } else if (gridCol == 3) {
                grid = 6;
            }
        }
        //Third row of grids
        else if (gridRow == 3) {
            if (gridCol == 1) {
                grid = 7;
            } else if (gridCol == 2) {
                grid = 8;
            } else if (gridCol == 3) {
                grid = 9;
            }
        }

        return grid;

    }

    public boolean checkRow(int row, int col, int num){

        for(int i = 0; i < 9; i++){ //Increment column
             if(col != i){
                 if(num == this.sudokuArray[row][i]){
                     return false; //Num already used
                 }
             }
        }

        return true; //passed

    }

    public boolean checkCol(int row, int col, int num){

        for(int i = 0; i < 9; i++){ //Increment col
            if(row != i){
                if(num == this.sudokuArray[i][col]){
                    return false; //Num already used
                }
            }
        }

        return true; //passed

    }

    public boolean checkGrid(int row, int col, int num){

        int gridNum = getGrid(row+1,col+1);

        for(int i = 0; i < 9; i++){ //row
            for(int j = 0; j < 9; j++){ //col

                int sameGrid = getGrid(i+1,j+1);

                if(sameGrid == gridNum){
                    if(i != row && j != col) {
                        if (num == this.sudokuArray[i][j]) {
                            return false; //Num already used
                        }
                    }
                }

            }
        }

        return true; //passed

    }

    public boolean checkAll(int row, int col, int num){

        if(checkRow(row,col,num) && checkCol(row,col,num) && checkGrid(row,col,num)){
            return true;
        }
        else{
            return false;
        }

    }

    public void printPuzzle(){

        for(int i = 0; i < 9; i++){
            System.out.println(this.sudokuArray[i][0] + " " + this.sudokuArray[i][1] + " " + this.sudokuArray[i][2] + " " + this.sudokuArray[i][3] + " " + this.sudokuArray[i][4] + " " + this.sudokuArray[i][5] + " " + this.sudokuArray[i][6] + " " + this.sudokuArray[i][7] + " " + this.sudokuArray[i][8]);
        }

    }

    public Stack returnValues(int row, int col){

        Stack<Integer> sNum = new Stack<>();

        for(int i = 1; i < 10; i++){

            if(checkAll(row,col,i)){
                sNum.push(i);
            }

        }

        return sNum;

    }

}