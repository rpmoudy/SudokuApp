package com.example.slick.sudokuapp;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayout;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog.Builder;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Random;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    GridLayout sGridLayout;
    GridLayout nGridLayout;
    GridLayout fGridLayout;
    TextView sTextView;
    TextView selectedTextView;
    TextView nTextView;
    TextView numTextView;
    ImageView fImageView;

    Random rand = new Random();

    SudokuGenerator sudokuSolved = new SudokuGenerator();
    int[][] sudokuValues = sudokuSolved.sudokuArray;
    int[] gridPosition = new int[2]; //Row and Column
    ArrayList<Integer> inputCells = new ArrayList<>();

    Timer clock = new Timer();
    TextView clockView;
    int seconds = 0;
    int minutes = 0;
    boolean gameStart = true;
    boolean pencilMode = false;

    Stack<Integer> blackNums = new Stack();
    ArrayList<Integer> redNums = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.grid_layout); //activity_main);
        sGridLayout = findViewById(R.id.myGridLayout);

        int pixels = 110;
        int difficulty = 40; //Easy 40-50%, Medium 30-40%, Hard 20-30% shown

        //Setup Timer
        clockView = new TextView(this);
        clockView.setTextSize(28);
        clockView.setWidth(300);
        clockView.setHeight(pixels);
        clockView.setGravity(Gravity.CENTER);
        clockView.setTextColor(Color.BLACK);
        clockView.setBackgroundColor(Color.WHITE);

        //Setting up Sudoku Puzzle
        for (int i = 0; i < 9; i++) { //Row position

            for (int j = 0; j < 9; j++) { //Column position

                sTextView = new TextView(this);
                sTextView.setTextSize(28);
                sTextView.setWidth(pixels);
                sTextView.setHeight(pixels);
                sTextView.setGravity(Gravity.CENTER);

                //Uncomment below for testing purposes
                //sTextView.setHint(String.valueOf(sudokuValues[i][j]));

                int showNum = rand.nextInt(100);
                sTextView.setHint(String.valueOf(sudokuValues[i][j])); //Compare with user input

                if(showNum <= difficulty) {
                    sTextView.setText((String.valueOf(sudokuValues[i][j]))); //Show Value
                    sTextView.setTextColor(Color.BLACK);
                }
                else{
                    sTextView.setText(" "); //Don't Show value
                    inputCells.add(i*9+j); //Keep track of user input cells
                }

                int grid = sudokuSolved.getGrid(i+1,j+1);

                if(grid == 1 || grid == 3 || grid == 5 || grid == 7 || grid == 9){
                    sTextView.setBackgroundResource(R.drawable.light_border);
                }
                else{
                    sTextView.setBackgroundResource(R.drawable.border);
                }

                GridLayout.Spec row = GridLayout.spec(i, 1); //Grid row starts at 0
                GridLayout.Spec col = GridLayout.spec(j, 1); //Grid col starts at 0
                GridLayout.LayoutParams gridLayoutParam = new GridLayout.LayoutParams(row, col);

                sGridLayout.addView(sTextView,gridLayoutParam); //Add TextView to Grid Layout

            }

        }

        //Check that adequate number of sudoku cells are populated.
        double cellPop = difficulty/100;
        if(inputCells.size() < cellPop*81){
            checkCellPop((int)cellPop*81);
        }

        //For user clicking Sudoku Cell
        int childCount = sGridLayout.getChildCount();

        for(int i = 0; i < childCount; i++){
            TextView container = (TextView) sGridLayout.getChildAt(i);
            container.setOnClickListener( new View.OnClickListener(){
                @Override
                public void onClick(View v) {

                    boolean alreadySelected = false;

                    if(selectedTextView == v){
                        alreadySelected = true;
                    }

                    selectedTextView = (TextView) v;

                    //Use getGridPosition() to highlight numbers and turn off when not selected
                    if(alreadySelected){ //Debounce selected sudoku cell
                        clearHighlights();
                        clearHighlights();//Have to call twice to clear up...
                        selectedTextView = null;
                    }
                    else{
                        getGridPosition(gridPosition, selectedTextView);
                        areaHighlight(gridPosition);
                    }

                    //Start game clock
                    if(gameStart){
                        clock.scheduleAtFixedRate(new TimerTask() {

                            @Override
                            public void run() {
                                runOnUiThread(new Runnable() {

                                    @Override
                                    public void run() {

                                        if(seconds < 10){
                                            clockView.setText(String.valueOf(minutes) + ":0" + String.valueOf(seconds));
                                        }
                                        else {
                                            clockView.setText(String.valueOf(minutes) + ":" + String.valueOf(seconds));
                                        }
                                        seconds++;

                                        if(seconds == 60)
                                        {
                                            clockView.setText(String.valueOf(minutes)+":"+String.valueOf(seconds));
                                            seconds=0;
                                            minutes++;
                                        }
                                    }
                                });
                            }
                        }, 0, 1000);

                        ActionBar actionBar = getSupportActionBar();
                        actionBar.setDisplayHomeAsUpEnabled(true);
                        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT,
                                ActionBar.LayoutParams.WRAP_CONTENT);
                        layoutParams.gravity = Gravity.RIGHT|Gravity.CENTER_HORIZONTAL;
                        actionBar.setCustomView(clockView,layoutParams);
                        actionBar.setDisplayShowCustomEnabled(true);

                        gameStart = false;

                    }

                }
            });
        }

        //Setting up numbers
        nGridLayout = findViewById(R.id.numGridLayout);

        for(int i = 0; i < 9; i++) {

            nTextView = new TextView(this);
            nTextView.setTextSize(28);
            nTextView.setWidth(pixels);
            nTextView.setHeight(pixels);
            nTextView.setGravity(Gravity.CENTER);
            nTextView.setTextColor(Color.BLACK);
            nTextView.setText(String.valueOf(i+1));
            nTextView.setBackgroundResource(R.drawable.border);

            GridLayout.Spec row = GridLayout.spec(0, 1); //Grid row starts at 0
            GridLayout.Spec col = GridLayout.spec(i, 1); //Grid col starts at 0
            GridLayout.LayoutParams gridLayoutParam = new GridLayout.LayoutParams(row, col);

            nGridLayout.addView(nTextView, gridLayoutParam); //Add TextView to Grid Layout

        }

        //For user clicking Number Cell
        int numChildCount = nGridLayout.getChildCount();

        for(int i = 0; i < numChildCount; i++){
            TextView container = (TextView) nGridLayout.getChildAt(i);
            container.setOnClickListener( new View.OnClickListener(){
                @Override
                public void onClick(View v) {

                    if(selectedTextView != null && editCell(selectedTextView)) {
                        numTextView = (TextView) v;
                        int num = getSelectedNum(numTextView);
                        checkNum(num,selectedTextView);
                        selectedTextView.setTextColor(Color.BLUE);
                        selectedTextView.setText(String.valueOf(num));
                        checkRedNums(); //Clear red numbers if possible
                    }

                    if(gameOver() || checkMultiSolutions()){
                       alertView("Wow, you actually won!");
                    }

                }
            });
        }

        //Setting up pencil mode and eraser cells
        fGridLayout = findViewById(R.id.featureGridLayout);

        fImageView = new ImageView(this);
        fImageView.setAdjustViewBounds(true);
        fImageView.setImageDrawable(getImage("eraser"));
        fImageView.setBackgroundResource(R.drawable.border);
        fImageView.setMaxWidth(pixels);
        fImageView.setMaxHeight(pixels);
        fImageView.setScaleType((ImageView.ScaleType.CENTER_INSIDE));

        GridLayout.Spec fRow = GridLayout.spec(0,1);
        GridLayout.Spec fCol = GridLayout.spec(0,1);

        GridLayout.LayoutParams fGridLayoutParam = new GridLayout.LayoutParams(fRow,fCol);

        fGridLayout.addView(fImageView,fGridLayoutParam); //Added eraser image

        fImageView = new ImageView(this);
        fImageView.setAdjustViewBounds(true);
        fImageView.setImageDrawable(getImage("pencil"));
        fImageView.setBackgroundResource(R.drawable.border);
        fImageView.setMaxWidth(pixels);
        fImageView.setMaxHeight(pixels);
        fImageView.setScaleType((ImageView.ScaleType.CENTER_INSIDE));

        fRow = GridLayout.spec(0,1);
        fCol = GridLayout.spec(1,1);

        fGridLayoutParam = new GridLayout.LayoutParams(fRow,fCol);

        fGridLayout.addView(fImageView,fGridLayoutParam); //Added pencil image

        //For User clicking feature cells
        numChildCount = fGridLayout.getChildCount();

        for(int i = 0; i < numChildCount; i++){
            final ImageView container = (ImageView) fGridLayout.getChildAt(i);
            final int pos = i;
            container.setOnClickListener( new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    switch(pos) {
                        case 0: //Erase user input on selected cell
                            if(selectedTextView != null && editCell(selectedTextView)) {
                                selectedTextView.setText(" ");
                                checkRedNums();
                                clearHighlights();
                            }
                            break;
                        case 1: //Pencil mode
                            if(pencilMode){
                                container.setColorFilter(null);
                                pencilMode = false;
                            }
                            else {
                                container.setColorFilter(Color.argb(150,200,200,200));
                                pencilMode = true;
                            }
                            break;
                    }
                }
            });
        }
    }

    //Check sudoku board is adequately populated, if not populate with more pre-defined cells.
    public void checkCellPop(int cellPop){

        int childCount = sGridLayout.getChildCount();
        int cellCount = 0;

        for(int i = 0; i < childCount; i++){
            TextView sView = (TextView) sGridLayout.getChildAt(i);

            if(sView.getText() != " "){
                cellCount++;
            }
        }

        while(cellCount < cellPop){

            for(int i = 0; i < childCount; i++) {

                int randomNum = rand.nextInt(100);
                TextView rView = (TextView) sGridLayout.getChildAt(i);

                if(randomNum <= 50 && inputCells.contains(i)){
                    rView.setText(rView.getHint());
                    rView.setTextColor(Color.BLACK);
                    inputCells.remove(i);
                    blackNums.add(i);
                    cellCount++;
                }

                if(cellCount >= cellPop){
                    break;
                }

            }
        }

    }

    //Get drawable of bitmap images
    public Drawable getImage(String name){

        Resources resources = this.getResources();
        final int resourceId = resources.getIdentifier(name, "drawable",
                this.getPackageName());
        return resources.getDrawable(resourceId);

    }

    //Sudoku cell can be edited
    private boolean editCell(TextView view){

        int childCount = sGridLayout.getChildCount();

        for(int i = 0; i < childCount; i++){
            TextView sView = (TextView) sGridLayout.getChildAt(i);
            if(sView == view){
                if(inputCells.contains(i)){
                    return true;
                }
                else{
                    break;
                }
            }
        }

        return false;

    }

    private void restartApp() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        int mPendingIntentId = this.getTaskId(); //May or may not be right?
        PendingIntent mPendingIntent = PendingIntent.getActivity(getApplicationContext(), mPendingIntentId, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager mgr = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
        System.exit(0);
    }

    private void alertView( String message ) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle( "GAME OVER" )
                .setIcon(R.drawable.ic_launcher_background)
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialoginterface, int i) {
                        restartApp();
                    }
                })
                //.setNegativeButton("No", new DialogInterface.OnClickListener() {
                 // public void onClick(DialogInterface dialoginterface, int i) {
                      //dialoginterface.cancel();
                     //}})
                .show();
    }

    public boolean checkMultiSolutions(){

        //GF showed game where multiple solutions worked. Luck of the draw that happened.
        //Check that all cells are filled in and no red nums, then second solution is found. Game over.

        int sudokuCellsLeft = 0;
        int childCount = sGridLayout.getChildCount();

        for(int i = 0; i < childCount; i++){

            TextView sView = (TextView) sGridLayout.getChildAt(i);

            if(sView.getText() == " "){
                sudokuCellsLeft++;
            }

        }

        if(sudokuCellsLeft == 0 && redNums.isEmpty()){
            clock.cancel();
            clock.purge();
            return true;
        }

        return false;

    }

    public boolean gameOver(){

        int sudokuCellsLeft = 0;
        int childCount = sGridLayout.getChildCount();

        for(int i = 0; i < childCount; i++){

            TextView sView = (TextView) sGridLayout.getChildAt(i);

            if(sView.getText() != sView.getHint()){
                sudokuCellsLeft++;
            }

        }

        if(sudokuCellsLeft == 0){
            clock.cancel();
            clock.purge();
            return true;
        }

        return false;

    }

    public void clearHighlights(){

        int childCount = sGridLayout.getChildCount();

        for(int i = 0; i < childCount; i++) {
            TextView sView = (TextView) sGridLayout.getChildAt(i);
            int row = i/9;
            int col = i%9;
            int grid = sudokuSolved.getGrid(row+1,col+1);

            if(grid == 1 || grid == 3 || grid == 5 || grid == 7 || grid == 9){
                sView.setBackgroundResource(R.drawable.light_border);
            }
            else{
                sView.setBackgroundResource(R.drawable.border);
            }
        }

        //Return numbers back to their respective text colors
        for(int i = 0; i < childCount; i++){
            TextView sView = (TextView) sGridLayout.getChildAt(i);

            if(!editCell(sView) && !redNums.contains(i)){ //editCell() not working? Look into this...
                sView.setTextColor(Color.BLACK);
            }
            else{
                //Do if else for blue/red colors
                if(redNums.contains(i)){
                    sView.setTextColor(Color.RED);
                }
                else {
                    if(blackNums.contains(i)){
                        sView.setTextColor(Color.BLACK);
                    }
                    else {
                        sView.setTextColor(Color.BLUE);
                    }
                }
            }
        }

    }

    public void checkRedNums(){

        int childCount = sGridLayout.getChildCount();
        ArrayList<Integer> removedNums = new ArrayList<>();

        for(int i = 0; i < childCount; i++){

            if(redNums.contains(i)){ //Sudoku cell has red number

                int pos = i;
                int row = pos/9;
                int col = pos%9;
                int grid = sudokuSolved.getGrid(row+1,col+1);
                boolean stillRed = false;

                TextView redNumView = (TextView) sGridLayout.getChildAt(i);
                int num = getTextNum(redNumView);

                for(int j = 0; j < childCount; j++){ //Check if number needs be red still

                    if(i != j){ //Not same position

                        TextView view = (TextView) sGridLayout.getChildAt(j);
                        if(row == j/9 || col == j%9 || grid == sudokuSolved.getGrid(j/9+1, j%9+1)){
                            if(view.getText() != " "){
                                if(num == Integer.valueOf((String)view.getText())){
                                    stillRed = true;
                                    break;
                                }
                            }
                        }

                    }

                }

                if(!stillRed){
                    removedNums.add(i); //redNums.remove(i) was crashing application...
                    if(blackNums.contains(i)) {
                        redNumView.setTextColor(Color.BLACK);
                    }
                    else{
                        redNumView.setTextColor(Color.BLUE);
                    }
                }

            }
        }

        redNums.removeAll(removedNums);

    }

    public void checkNum(int num, TextView v){

        int childCount = sGridLayout.getChildCount();
        int pos = 0;

        for(int i = 0; i < childCount; i++){
            TextView view = (TextView) sGridLayout.getChildAt(i);
            if(view == v){
                pos = i;
                break;
            }
        }

        int row = pos/9;
        int col = pos%9;
        int grid = sudokuSolved.getGrid(row+1,col+1);

        for(int i = 0; i < childCount; i++){
            TextView view = (TextView) sGridLayout.getChildAt(i);
            if(row == i/9 || col == i%9 || grid == sudokuSolved.getGrid(i/9+1, i%9+1)){
                if(view.getText() != " "){
                    if(num == Integer.valueOf((String)view.getText())){
                        if(!redNums.contains(i)) { //&& view.getCurrentTextColor() != Color.BLUE
                            redNums.add(i);//Add position in Sudoku Board
                            view.setTextColor(Color.RED);
                        }
                    }
                }
            }
        }
    }

    public void areaHighlight(int[] arr){

        int row = arr[0];
        int col = arr[1];
        int pos = row*9+col; //selected position
        int childCount = sGridLayout.getChildCount();
        int num = 0;

        //Clear background highlights... Call it twice for some reason.
        clearHighlights();
        clearHighlights();

        for(int i = 0; i < childCount; i++){
            TextView sView = (TextView) sGridLayout.getChildAt(i);

            if(i/9 == row || i%9 == col){
                if(pos == i){
                    num = getTextNum(sView);
                    sView.setBackgroundResource(R.drawable.selected_border);
                    break;
                }
            }

        }

        //If selection has number already, highlight other of same number
        if(num != 0){
            for(int i = 0; i < childCount; i++){
                TextView sView = (TextView) sGridLayout.getChildAt(i);
                int temp = getTextNum(sView);

                if(num == temp && i != pos){
                    if(sView.getCurrentTextColor() == Color.BLACK){
                        blackNums.push(i); //Keep track of nums user did not enter
                    }
                    sView.setTextColor(Color.GREEN);
                }

            }
        }

    }

    public int getSelectedNum(TextView view){

        int numChildCount = nGridLayout.getChildCount();
        int num = 0;

        for(int i = 0; i < numChildCount; i++){
            TextView viewCompare = (TextView) nGridLayout.getChildAt(i);
            if(viewCompare == view){
                num = i+1;
                break;
            }
        }

        return num;

    }

    public void getGridPosition(int[] arr, TextView view){

        int childCount = sGridLayout.getChildCount();

        for(int i = 0; i < childCount; i++) {
            TextView viewCompare = (TextView) sGridLayout.getChildAt(i);
            if(viewCompare == view){
                arr[0]= i/9; //row
                arr[1] = i%9; //column
                break;
            }
        }

    }

    public int getTextNum(TextView sView){

        int num = 0;

        if(sView.getText() != " "){
            num = Integer.valueOf((String)sView.getText());
        }

        return num;

    }

}